﻿#requires -Version 5.1
Set-StrictMode -Version 2.0
$ErrorActionPreference = "Stop"

$Source = Join-Path $PSScriptRoot "tools\release"
$Destination = Join-Path (Get-Location).Path "tools\release"

if (-not (Test-Path (Join-Path (Get-Location).Path "manage.py"))) {
    throw "Execute este instalador na raiz do Cashback System, onde esta o manage.py."
}

if (-not (Test-Path $Destination)) {
    New-Item -ItemType Directory -Path $Destination -Force | Out-Null
}

Copy-Item -Path (Join-Path $Source "*") -Destination $Destination -Recurse -Force

Write-Host "Pipeline instalado em:"
Write-Host $Destination
Write-Host ""
Write-Host "Nenhuma branch, commit ou configuracao Git foi alterada."
